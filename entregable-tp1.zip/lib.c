#include "lib.h"

/** STRING **/

char* strRange(char* a, uint32_t i, uint32_t f) {

    return 0;
}

/** Lista **/

void listPrintReverse(list_t* l, FILE *pFile, funcPrint_t* fp) {

}

/** n3tree **/

void n3treePrintAux(n3treeElem_t** t, FILE *pFile, funcPrint_t* fp) {

}

void n3treePrint(n3tree_t* t, FILE *pFile, funcPrint_t* fp) {

}

/** nTable **/

void nTableRemoveAll(nTable_t* t, void* data, funcCmp_t* fc, funcDelete_t* fd) {

}

void nTablePrint(nTable_t* t, FILE *pFile, funcPrint_t* fp) {

}
